-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11e101.p.ssafy.io    Database: mydb
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `usertable_id` bigint NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) DEFAULT NULL,
  `img_no` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `user_pw` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`usertable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (5,'2024-09-26 03:48:46.367147','https://d1ttm6rxzek9kw.cloudfront.net/bc32c178-3userImage.png',NULL,'1','1','1'),(6,'2024-09-26 05:27:18.236409','https://d1ttm6rxzek9kw.cloudfront.net/2f7531af-2userImage.png',NULL,'2','1','1'),(7,'2024-09-26 05:47:48.852282','https://d1ttm6rxzek9kw.cloudfront.net/9db0f61e-cuserImage.png',NULL,'5','1234','123'),(8,'2024-09-26 05:48:19.742366','https://d1ttm6rxzek9kw.cloudfront.net/9c63a8ed-7userImage.png',NULL,'123456','12345','123'),(9,'2024-09-26 07:05:57.545136','https://d1ttm6rxzek9kw.cloudfront.net/dd68c292-4userImage.png',NULL,'zkcvg210','1234','김태훈'),(10,'2024-09-26 08:07:12.276060','https://d1ttm6rxzek9kw.cloudfront.net/f9d576c3-5userImage.png','위대한 이순신','123445','1234','123'),(11,'2024-09-27 06:30:04.655436','https://d1ttm6rxzek9kw.cloudfront.net/a3162d5a-2userImage.png',NULL,'znight1020','1q2w3e4r','이현수'),(12,'2024-09-27 06:40:18.000425','https://d1ttm6rxzek9kw.cloudfront.net/80c51c68-0userImage.png',NULL,'thsqowns2','sonbezon2!','상범킹'),(13,'2024-09-27 06:47:04.241604','https://d1ttm6rxzek9kw.cloudfront.net/edda0578-9userImage.png',NULL,'asdf1234','asdf1234','응애'),(14,'2024-10-02 01:00:12.093400','https://d1ttm6rxzek9kw.cloudfront.net/fc7c023b-4userImage.png',NULL,'테스트용입니다','1234','test123'),(15,'2024-10-02 01:49:32.501901','https://d1ttm6rxzek9kw.cloudfront.net/cfaf57ab-8userImage.png','위대한 이순신','zxader','1234','김태훈'),(16,'2024-10-02 01:50:18.105635','https://d1ttm6rxzek9kw.cloudfront.net/62adb626-9userImage.png',NULL,'test1234','1234','test123'),(17,'2024-10-02 03:04:03.284585','https://d1ttm6rxzek9kw.cloudfront.net/533bfd77-fuserImage.png',NULL,'asdasd','1234','r123'),(18,'2024-10-02 03:06:26.698309','https://d1ttm6rxzek9kw.cloudfront.net/d46f9f54-0userImage.png',NULL,'test123321','1234','테스트임1112321'),(19,'2024-10-02 03:07:49.460338','https://d1ttm6rxzek9kw.cloudfront.net/ea1497ba-9userImage.png','위대한 이순신','test','test','test'),(20,'2024-10-02 03:08:28.627664','https://d1ttm6rxzek9kw.cloudfront.net/db982669-4userImage.png','위대한 이순신','jskwon','1234','정솔'),(21,'2024-10-02 08:43:58.423509','https://d1ttm6rxzek9kw.cloudfront.net/f8f50e57-9userImage.png',NULL,'lee','123','위대한 이순신'),(22,'2024-10-02 08:53:06.673144','https://d1ttm6rxzek9kw.cloudfront.net/4e97a57e-6userImage.png',NULL,'lee1','123','불멸의 이순신'),(23,'2024-10-02 12:27:30.777224','https://d1ttm6rxzek9kw.cloudfront.net/9263e2bf-auserImage.png',NULL,'z','z','z'),(24,'2024-10-02 13:33:14.339760','https://d1ttm6rxzek9kw.cloudfront.net/e1d700af-auserImage.png',NULL,'test23','1234','test23'),(25,'2024-10-03 07:10:44.223032','https://d1ttm6rxzek9kw.cloudfront.net/73f3962c-4userImage.png',NULL,'test1235','test1234','테스트22'),(26,'2024-10-03 14:25:38.248570','https://d1ttm6rxzek9kw.cloudfront.net/37771494-8userImage.png',NULL,'55','123','123123'),(27,'2024-10-03 16:02:01.147335','https://d1ttm6rxzek9kw.cloudfront.net/cbb551f4-0userImage.png','위대한 이순신','thingco','123123123','thingco'),(28,'2024-10-04 00:56:34.084803','https://d1ttm6rxzek9kw.cloudfront.net/0a2c8189-7userImage.png',NULL,'dddad','12345','불타는화장실'),(29,'2024-10-04 01:42:21.567124','https://d1ttm6rxzek9kw.cloudfront.net/6134f9a6-0userImage.png',NULL,'sungwoo166','sungwoo166','홍성우'),(30,'2024-10-04 01:43:24.584552','https://d1ttm6rxzek9kw.cloudfront.net/52040797-5userImage.png',NULL,'ssafybada','ssafy123','coach1'),(31,'2024-10-04 01:43:27.160689','https://d1ttm6rxzek9kw.cloudfront.net/bf6f9118-0userImage.png',NULL,'silver','12345','coacheunhui'),(32,'2024-10-04 01:43:34.379472','https://d1ttm6rxzek9kw.cloudfront.net/c45eb7ca-duserImage.png',NULL,'ddd','ddd','ddd'),(33,'2024-10-04 01:43:59.737674','https://d1ttm6rxzek9kw.cloudfront.net/b4c549a3-9userImage.png',NULL,'안녕하세요','1ㅂ2ㅈ3ㄷ4ㄱ','이현수'),(34,'2024-10-04 01:44:35.844032','https://d1ttm6rxzek9kw.cloudfront.net/96d7fa51-7userImage.png',NULL,'ziho','ziho','ziho'),(35,'2024-10-04 01:44:48.004810','https://d1ttm6rxzek9kw.cloudfront.net/54f1dfba-buserImage.png',NULL,'s007kk@ajou.ac.kr','gmltn6614','정희수'),(36,'2024-10-04 01:45:04.770485','https://d1ttm6rxzek9kw.cloudfront.net/e5693cda-3userImage.png',NULL,'picel','asdzxcfv10','김상범'),(37,'2024-10-04 02:11:44.326416','https://d1ttm6rxzek9kw.cloudfront.net/cd12725e-3userImage.png',NULL,'ckdgh','1234','창호리'),(38,'2024-10-04 06:52:10.145496','https://d1ttm6rxzek9kw.cloudfront.net/f1fdfb58-euserImage.png',NULL,'asd','asd','asd'),(39,'2024-10-04 08:47:54.305633','https://d1ttm6rxzek9kw.cloudfront.net/4454a566-5userImage.png',NULL,'test0804','1234','김태훈'),(40,'2024-10-04 08:58:55.735660','https://d1ttm6rxzek9kw.cloudfront.net/22531ee1-duserImage.png','위대한 이순신','asdf','1234','asd'),(41,'2024-10-05 05:31:56.204676','https://d1ttm6rxzek9kw.cloudfront.net/c968462a-buserImage.png',NULL,'qwe','1234','이종휘'),(42,'2024-10-07 03:35:57.193372','https://d1ttm6rxzek9kw.cloudfront.net/7f2ecf14-6userImage.png',NULL,'yssssse99','Eun8514@','양시은'),(43,'2024-10-08 03:31:12.006169','https://d1ttm6rxzek9kw.cloudfront.net/d993ab74-9userImage.png',NULL,'lee123','123','이순신'),(44,'2024-10-08 03:33:42.026015','https://d1ttm6rxzek9kw.cloudfront.net/1a98aec7-8userImage.png',NULL,'lee1234','1234','이순신'),(45,'2024-10-08 05:49:16.549530','https://d1ttm6rxzek9kw.cloudfront.net/4ccbecd0-7userImage.png',NULL,'abcde','abcde123','홍길동'),(46,'2024-10-08 08:55:21.046377','https://d1ttm6rxzek9kw.cloudfront.net/5e1a02bf-buserImage.png',NULL,'haha0601','hahahah0601!','하정솔'),(47,'2024-10-08 08:57:00.796191','https://d1ttm6rxzek9kw.cloudfront.net/5800b18e-cuserImage.png',NULL,'haha06010','haha0601','정권솔'),(48,'2024-10-08 13:48:37.686057','https://d1ttm6rxzek9kw.cloudfront.net/2df2a7d7-4userImage.png','위대한 이순신','싸피12','1234','싸피'),(49,'2024-10-09 05:32:14.203898','https://d1ttm6rxzek9kw.cloudfront.net/4cc9c5b4-2userImage.png',NULL,'si','1234','시연용'),(50,'2024-10-09 09:20:12.298418','https://d1ttm6rxzek9kw.cloudfront.net/310e4b7a-1userImage.png','위대한 이순신','싸피9','1234','싸피'),(51,'2024-10-09 09:49:37.499709','https://d1ttm6rxzek9kw.cloudfront.net/50da9409-cuserImage.png','위대한 이순신','싸피10','1234','싸피10'),(52,'2024-10-09 10:17:07.156087','https://d1ttm6rxzek9kw.cloudfront.net/c2f3aea8-5userImage.png',NULL,'싸피11','1234','싸피11'),(53,'2024-10-09 15:07:03.637860','https://d1ttm6rxzek9kw.cloudfront.net/13f4a9c6-9userImage.png',NULL,'coachsilver','ssa1234!','coachsilver'),(54,'2024-10-10 01:04:16.954285','https://d1ttm6rxzek9kw.cloudfront.net/fb7565b4-8userImage.png',NULL,'싸피13','1234','싸피13'),(55,'2024-10-10 03:10:36.282285','https://d1ttm6rxzek9kw.cloudfront.net/2d185ebc-4userImage.png',NULL,'aa12','abc123','조원빈'),(56,'2024-10-10 05:45:56.613383','https://d1ttm6rxzek9kw.cloudfront.net/b1134caa-fuserImage.png','위대한 이순신','싸피14','1234','싸피14'),(57,'2024-10-10 06:28:04.133687','https://d1ttm6rxzek9kw.cloudfront.net/097a8fe2-8userImage.png','위대한 이순신','tpwls1355','sejin1234','김세진');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 17:24:38
